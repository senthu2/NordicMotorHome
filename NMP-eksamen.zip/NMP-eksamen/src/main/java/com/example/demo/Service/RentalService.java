package com.example.demo.Service;

import com.example.demo.Repository.RentalRepo;
import com.example.demo.Model.Cars;
import com.example.demo.Model.Rental;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class RentalService
{
    @Autowired
    RentalRepo rentalrepo;

    //This service class makes a connection between the homecontroller and the Repository where the SQL lies.
    //That means almost every method here just picks up the object from the controller and send it straight to RentalRepo
    public List<Rental> fetchAll()
    {
        return rentalrepo.fetchAll();
    }

    public Cars chooseCar(String from, String to, int price)
    {
        return rentalrepo.chooseCar(from, to, price);
    }
    public Rental createRental(Rental r)
    {
        return rentalrepo.createRental(r);
    }

    public Rental findRentalById(int id)
    {
        return rentalrepo.findRentalById(id);
    }

    public Boolean deleteRental(int id)
    {
        return rentalrepo.deleteRental(id);
    }



    /**
     * @param id Bilens id
     * @param r  Rental objekt
     * @return   Rental objekt
     */
    public Rental returnerBil(int id, Rental r)
    {
        //This method calculates a new total price if you have driven too far or forgot to fill up the tank
        double price = r.getTotal_price();

        //add extra km charge beyond 400km/day
        price += Math.max(0, ((r.getOverDriven()-r.getMileage())-(r.getDays_of_rental()*400))* 1.0);  // 1.0 euro/km



        if (!r.isTank_Filled())
        {
            price+= 70;
        }

        r.setTotal_price(price);
        return rentalrepo.returnerBil(id, r);
    }

    //This Method just calls the rentalRepo to get the result
    public Rental getRentalPrice(Rental r)
    {
        return rentalrepo.getRentalPrice(r);
    }

    public Rental fetchInfo(int rental_id){

        return rentalrepo.fetchInfo(rental_id);
    }

}
