package com.example.demo.Model;

import javax.persistence.Entity;
import javax.persistence.Id;

@Entity

public class PickUpPoint
{
    @Id
    int pickUP_id;
    String place;
    double kmAway;

    public PickUpPoint()
    {

    }

    public PickUpPoint(int pickUP_id, String place, double kmAway)
    {
        this.pickUP_id = pickUP_id;
        this.place = place;
        this.kmAway = kmAway;
    }

    //Getters and setters for every field
    public int getPickUP_id() {
        return pickUP_id;
    }

    public void setPickUP_id(int pickUP_id) {
        this.pickUP_id = pickUP_id;
    }

    public String getPlace() {
        return place;
    }

    public void setPlace(String place) {
        this.place = place;
    }

    public double getKmAway() {
        return kmAway;
    }

    public void setKmAway(double kmAway) {
        this.kmAway = kmAway;
    }

    //This calculates the price from the office to the pickup point
    public double getDrivePrice()
    {
        return kmAway * 0.7;
    }

    //This formats the price nicely with only 2 decimals when displayed
    public String getDrivePriceStr()
    {
        double price = kmAway * 0.7;
        return String.format("%.2f",price);
    }
}
