package com.example.demo.Repository;

import com.example.demo.Model.Cancel;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.BeanPropertyRowMapper;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public class CancelRepo {
    @Autowired
    JdbcTemplate template;

    public List<Cancel> fetchAll(){
        String sql = "SELECT * FROM cancel";
        RowMapper<Cancel> rowMapper = new BeanPropertyRowMapper<>(Cancel.class);
        return template.query(sql, rowMapper);
    }

    public Cancel createCancel(Cancel ca)
    {
        String sql = "insert into cancel (cancel_id, cancel_price, cancel_date, cancel_days) values(?,?,?,?)";
        template.update(sql, ca.getCancel_id(), ca.getCancel_price(), ca.getCancel_date(), ca.getCancel_days());
        return null;
    }

    public Cancel findCancelById(int cancel_id)
    {
        String sql = "SELECT * FROM cancel where cancel_id = ?";
        RowMapper<Cancel> rowMapper = new BeanPropertyRowMapper<>(Cancel.class);
        Cancel ca = template.queryForObject(sql, rowMapper,cancel_id);
        return ca;
    }

    public Boolean deleteCancel(int cancel_id)
    {
        String sql = "DELETE FROM cancel WHERE cancel_id = ?";
        return template.update(sql, cancel_id) < 0;
    }
}
