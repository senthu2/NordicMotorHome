package com.example.demo.Service;

import com.example.demo.Model.Cancel;
import com.example.demo.Repository.CancelRepo;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class CancelService {
    @Autowired
    CancelRepo cancelRepo;
    public List<Cancel> fetchAll()
    {
        return cancelRepo.fetchAll();
    }

    public Cancel createCancel(Cancel ca)
    {
        return cancelRepo.createCancel(ca);
    }

    public Cancel findCancelById(int cancel_id)
    {
        return cancelRepo.findCancelById(cancel_id);
    }

    public Boolean deleteCancel(int cancel_id)
    {
        return cancelRepo.deleteCancel(cancel_id);
    }
}
